package com.saucelabs.mydemoapp.android.utils.base;

import androidx.lifecycle.ViewModel;

public class BaseViewModel extends ViewModel {
}
