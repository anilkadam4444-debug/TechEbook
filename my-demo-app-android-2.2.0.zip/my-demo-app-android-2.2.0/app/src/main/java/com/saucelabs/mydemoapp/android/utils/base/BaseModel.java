package com.saucelabs.mydemoapp.android.utils.base;

import java.io.Serializable;

public abstract class BaseModel implements Serializable {
}
