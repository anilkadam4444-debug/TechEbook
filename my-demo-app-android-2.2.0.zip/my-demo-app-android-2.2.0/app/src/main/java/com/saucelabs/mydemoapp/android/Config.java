package com.saucelabs.mydemoapp.android;

public class Config {
	public static final String TAG = "SauceLabs";
}
