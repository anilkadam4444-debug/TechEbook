package com.saucelabs.mydemoapp.android.interfaces;


public interface OnItemClickListener {
    void OnClick(int position, int status);
}
