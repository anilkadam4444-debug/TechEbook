package com.saucelabs.mydemoapp.android.interfaces;

public interface OnDialogCallBack {
    void OnDialogCallBack(boolean isOk);
}
